<?php

return [
    // Valeurs par défaut. Elles se modifient depuis Admin → Paramètres (prioritaires sur ce fichier).
    'name' => 'Maison Filali',
    'phone' => env('SHOP_PHONE', '06 78 20 88 68'),
    // Adresse qui reçoit les messages du formulaire de contact
    'contact_email' => env('SHOP_CONTACT_EMAIL', 'contact@maisonfilali.com'),
    'whatsapp' => env('SHOP_WHATSAPP', '212678208868'),

    // WhatsApp Cloud API (Meta for Developers) — réglé dans Admin → Paramètres → « WhatsApp (Meta) »
    'order_alerts' => null,                                   // numéros de l'équipe (JSON)
    'wa_phone_id' => env('WHATSAPP_PHONE_ID'),                // « Identifiant du numéro de téléphone »
    'wa_token' => env('WHATSAPP_TOKEN'),                      // jeton d'accès permanent
    'wa_template' => env('WHATSAPP_TEMPLATE', 'maison_filali_commande'),
    'wa_client_template' => env('WHATSAPP_CLIENT_TEMPLATE'),  // vide = pas de message au client
    'wa_lang' => env('WHATSAPP_LANG', 'fr'),
    'wa_api_version' => env('WHATSAPP_API_VERSION', 'v23.0'),

    // SEO (Admin → Paramètres → Référencement)
    'google_verification' => env('GOOGLE_SITE_VERIFICATION'),   // balise Google Search Console
    'bing_verification' => env('BING_SITE_VERIFICATION'),       // balise Bing Webmaster Tools
    'shipping_fee' => env('SHOP_SHIPPING_FEE'),                 // frais de livraison Maroc en DH (0 = offerte)
    'instagram' => '@la_maison_filalii',
    'instagram_url' => 'https://www.instagram.com/la_maison_filalii/',
    // Laisser vide (null) pour masquer l'icône sur le site
    'facebook_url' => env('SHOP_FACEBOOK_URL'),
    'tiktok_url' => env('SHOP_TIKTOK_URL'),
    'domain' => 'https://maisonfilali.com',
    // true = demander à Google de ne rien indexer (site de test). Laisser false en ligne.
    'noindex' => (bool) env('SHOP_NOINDEX', false),
    'address' => "Roches Noires, Maamoura, Ennakhil\nLot L1 — Casablanca, Maroc",
    'address_short' => "Roches Noires, Maamoura,\nEnnakhil — Casablanca",
    'hours' => 'Lundi – Samedi · 10h – 20h',
    'hours_short' => 'Lun – Sam · 10h – 20h',
    'maps_url' => 'https://maps.google.com/?cid=2549449862841452867',
    // Carte Google Maps intégrée (adresse « src » de l'iframe). Modifiable dans Admin → Paramètres.
    'maps_embed' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d53222.234114533545!2d-7.783073851367175!3d33.51725400000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xda62b001dc39fa5%3A0x2361772487554943!2sMaison%20filali!5e0!3m2!1sfr!2sma!4v1793365428807!5m2!1sfr!2sma',

    // false = les e-mails (mot de passe oublié…) partent tout de suite, sans file d'attente.
    // Mettre true seulement si un « queue worker » tourne sur le serveur.
    'queue_worker' => (bool) env('SHOP_QUEUE_WORKER', false),

    // Produits par page dans la boutique
    'per_page' => 12,

    // Nombre maximum de catégories dans le menu du haut (au-delà, le menu ne tient plus à côté du logo)
    'menu_max' => 2,

    // Seuil « stock faible » (en pièces)
    'low_stock' => 2,

    // Version des fichiers CSS/JS (à changer pour vider le cache des navigateurs)
    'assets_version' => '1.5.9',

    'cities' => [
        'Casablanca', 'Rabat', 'Marrakech', 'Fès', 'Tanger', 'Agadir', 'Meknès', 'Oujda', 'Kénitra', 'Tétouan',
        'Salé', 'Mohammedia', 'El Jadida', 'Settat', 'Béni Mellal', 'Nador', 'Safi', 'Khouribga', 'Témara',
        'Laâyoune', 'Dakhla', 'Essaouira', 'Ouarzazate', 'Errachidia', 'Taza', 'Berrechid', 'Khémisset',
        'Larache', 'Guelmim', 'Ifrane', 'Autre ville',
    ],
];
