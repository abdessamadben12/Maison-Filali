<?php

namespace App\Support;

use App\Models\Size;

/**
 * Pages de contenu du site. Les textes marqués [à compléter] doivent être
 * remplis avec les informations officielles de Maison Filali.
 */
class Pages
{
    /** @return array<int, string> */
    public static function slugs(): array
    {
        return ['notre-histoire', 'comment-commander', 'guide-des-tailles', 'livraison-retours', 'mentions-legales', 'confidentialite', 'cgv'];
    }

    public static function find(string $slug): ?array
    {
        $phone = e(config('shop.phone'));

        return match ($slug) {
            'notre-histoire' => [
                'eyebrow' => 'Maison Filali',
                'title' => 'Notre histoire',
                'seo_title' => 'Notre histoire — caftans faits main à Fès | Maison Filali',
                'description' => 'Maison Filali : caftans, takchitas, djellabas et babouches faits main par nos artisans à Fès. Showroom à Casablanca, livraison au Maroc et à l’international.',
                'html' => '<p>Maison Filali propose des vêtements traditionnels marocains : caftans, takchitas, djellabas et babouches, faits main. Depuis plus d’un an, nos clientes nous retrouvent sur Instagram et WhatsApp ; nos pièces sont faites main par nos artisans à Fès, et ce site permet de commander directement : livraison au Maroc et à l’international, paiement à la livraison au Maroc.</p>
<h2>Nos créations</h2><p>Broderies, finitions sfifa et aakad, couleurs choisies avec soin : chaque pièce est pensée pour les fêtes comme pour le quotidien. La plupart de nos modèles peuvent aussi être réalisés sur mesure.</p>
<p>[Histoire de la marque à compléter par Maison Filali]</p>
<h2>Nous rendre visite</h2><p>'.nl2br(e(config('shop.address'))).'<br>'.e(config('shop.hours')).'<br>Téléphone / WhatsApp : '.$phone.'</p>',
            ],
            'comment-commander' => [
                'eyebrow' => 'Aide',
                'title' => 'Comment commander',
                'description' => 'Commander chez Maison Filali en 4 étapes : choisissez votre modèle, laissez vos coordonnées, notre équipe confirme sous 24 h, vous payez à la livraison.',
                'html' => '<ul>
<li><strong>Choisissez</strong> votre modèle, la couleur et la taille sur la page produit, puis cliquez sur « Commander ».</li>
<li><strong>Indiquez vos coordonnées</strong> : nom, téléphone et ville. Aucun compte n’est nécessaire.</li>
<li><strong>Notre équipe confirme</strong> votre commande sous 24 h. Vous suivez son statut sur le site (page « Suivre ma commande » ou votre espace client).</li>
<li><strong>Payez à la livraison</strong>, en espèces, à réception de votre colis.</li>
</ul><p>Une question ? Écrivez-nous sur WhatsApp au '.$phone.'.</p>',
            ],
            'guide-des-tailles' => [
                'eyebrow' => 'Aide',
                'title' => 'Guide des tailles',
                'seo_title' => 'Guide des tailles — caftans, djellabas & babouches | Maison Filali',
                'description' => 'Trouvez votre taille de caftan, takchita, djellaba ou babouches : tableau des mesures Maison Filali. Toutes nos pièces existent aussi sur mesure.',
                'html' => self::sizeGuide(),
            ],
            'livraison-retours' => [
                'eyebrow' => 'Aide',
                'title' => 'Livraison & retours',
                'description' => 'Livraison partout au Maroc en 24 à 72 h, paiement à la livraison, et livraison à l’international. Échange ou retour possible sous 7 jours.',
                'html' => '<h2>Livraison</h2><p>Nous livrons partout au Maroc en 24 à 72 h après confirmation de la commande. Le paiement se fait en espèces à la livraison. Frais de livraison : '.(is_numeric(config('shop.shipping_fee')) ? ((float) config('shop.shipping_fee') > 0 ? money(config('shop.shipping_fee')) : 'offerts') : '[à compléter]').'.</p>
<h2>Livraison à l’international</h2><p>Nous livrons aussi hors du Maroc. Le tarif, le délai et le mode de paiement dépendent du pays : écrivez-nous sur WhatsApp au '.$phone.' avec le modèle souhaité et votre pays. [Pays desservis, tarifs et délais à compléter]</p>
<h2>Échanges et retours</h2><p>Vous pouvez échanger ou retourner un article sous 7 jours après réception, s’il n’a pas été porté et qu’il est rendu dans son emballage d’origine. Les pièces réalisées sur mesure ne sont ni reprises ni échangées. [Conditions de remboursement à compléter]</p>
<p>Pour demander un échange : '.$phone.' (téléphone ou WhatsApp).</p>',
            ],
            'mentions-legales' => [
                'eyebrow' => 'Informations',
                'title' => 'Mentions légales',
                'description' => 'Mentions légales du site maisonfilali.com : éditeur, coordonnées et hébergement.',
                'html' => '<p><strong>Éditeur du site :</strong> Maison Filali — [raison sociale, forme juridique et capital à compléter]<br>Adresse : '.nl2br(e(config('shop.address'))).'<br>RC : [à compléter] · ICE : [à compléter] · IF : [à compléter]<br>Téléphone : '.$phone.'</p>
<p><strong>Hébergement :</strong> [nom et adresse de l’hébergeur à compléter]</p>',
            ],
            'confidentialite' => [
                'eyebrow' => 'Informations',
                'title' => 'Confidentialité',
                'description' => 'Comment Maison Filali utilise vos données (nom, téléphone, adresse) : uniquement pour traiter et livrer votre commande, conformément à la loi 09-08.',
                'html' => '<p>Les informations que vous donnez lors d’une commande (nom, téléphone, ville, adresse, e-mail si vous créez un compte) servent uniquement à traiter et livrer votre commande. Elles ne sont ni vendues ni partagées, sauf avec le livreur pour la livraison.</p>
<p>Conformément à la loi 09-08, vous pouvez demander l’accès, la rectification ou la suppression de vos données en nous contactant au '.$phone.'. [Numéro de déclaration CNDP à compléter]</p>',
            ],
            'cgv' => [
                'eyebrow' => 'Informations',
                'title' => 'Conditions générales de vente',
                'description' => 'Conditions générales de vente Maison Filali : commande, prix en dirhams, paiement à la livraison, délais de livraison et échanges.',
                'html' => '<h2>Commande</h2><p>Toute commande passée sur le site est enregistrée puis confirmée par Maison Filali, par téléphone ou via le site, sous réserve de disponibilité.</p>
<h2>Prix et paiement</h2><p>Les prix sont indiqués en dirhams (DH) TTC. Le paiement s’effectue en espèces à la livraison.</p>
<h2>Livraison</h2><p>Maroc : livraison en 24 à 72 h après confirmation, paiement à la livraison. International : livraison sur demande, conditions communiquées avant l’expédition.</p>
<h2>Échanges</h2><p>Échange possible sous 7 jours après réception, article non porté et dans son emballage. Les créations sur mesure ne sont pas échangeables.</p>
<p>[Conditions complètes à valider par Maison Filali]</p>',
            ],
            default => null,
        };
    }

    private static function sizeGuide(): string
    {
        $html = '<p>Mesurez-vous sans serrer le mètre ruban. En cas de doute entre deux tailles, prenez la plus grande ou contactez-nous sur WhatsApp.</p>';
        $clothes = Size::where('type', 'vetement')->orderBy('position')->get();
        if ($clothes->count()) {
            $html .= '<h2>Caftans, takchitas, djellabas</h2><table><tr><th>Taille</th><th>Mesure</th></tr>';
            foreach ($clothes as $s) {
                $html .= '<tr><td>'.e($s->name).'</td><td>'.e($s->guide ?: '—').'</td></tr>';
            }
            $html .= '</table>';
        }
        $shoes = Size::where('type', 'pointure')->orderBy('position')->get();
        if ($shoes->count()) {
            $html .= '<h2>Babouches</h2><table><tr><th>Pointure</th><th>Longueur du pied</th></tr>';
            foreach ($shoes as $s) {
                $html .= '<tr><td>'.e($s->name).'</td><td>'.e($s->guide ?: '—').'</td></tr>';
            }
            $html .= '</table>';
        }

        return $html.'<p>Toutes nos pièces peuvent aussi être réalisées sur mesure.</p>';
    }
}
