<?php

namespace App\Http\Controllers;

use App\Mail\ContactMessageReceived;
use App\Models\ContactMessage;
use Illuminate\Support\Facades\Mail;
use Throwable;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ContactController extends Controller
{
    public function show()
    {
        return view('site.contact');
    }

    public function send(Request $request)
    {
        // Champ piège anti-robots : doit rester vide
        if (filled($request->input('website'))) {
            return redirect()->to(route('contact').'#formulaire')->with('contact_sent', '');
        }

        $request->merge(['phone' => normalize_phone($request->input('phone'))]);
        $data = $request->validate([
            'name' => ['required', 'string', 'min:2', 'max:80'],
            'phone' => ['required', 'regex:/^0[5-7][0-9]{8}$/'],
            'email' => ['nullable', 'email', 'max:190'],
            'subject' => ['required', Rule::in(array_keys(ContactMessage::SUBJECTS))],
            'message' => ['required', 'string', 'min:10', 'max:3000'],
        ], ['phone.regex' => 'Entrez un numéro marocain valide (ex. 06 12 34 56 78).']);

        $message = ContactMessage::create($data);

        // Copie par e-mail à Maison Filali (adresse réglable dans Admin → Paramètres).
        // Si l'envoi échoue, le message reste enregistré dans l'admin (menu « Messages »).
        if ($to = config('shop.contact_email')) {
            try {
                Mail::to($to)->send(new ContactMessageReceived($message));
            } catch (Throwable $e) {
                report($e);
            }
        }

        // Prénom avec majuscule (« abdessamad » → « Abdessamad »)
        $first = mb_convert_case(mb_strtolower(explode(' ', trim($data['name']))[0]), MB_CASE_TITLE);

        return redirect()->to(route('contact').'#formulaire')->with('contact_sent', $first);
    }
}
